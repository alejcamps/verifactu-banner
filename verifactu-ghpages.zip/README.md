# VeriFactu Banner JSON

Este repositorio sirve el archivo banner.json vía GitHub Pages con CORS habilitado.